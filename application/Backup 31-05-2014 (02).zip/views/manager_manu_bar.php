<aside>
    <div id="sidebar"  class="nav-collapse" style="z-index: 1">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
            <li class="active">
                <a class="" href="<?php echo site_url('con_proc_daily_dashoard_report/view_dashboard_report'); ?>">
                    <i class="icon-dashboard"></i>
                    <span>Dashboard</span>                    
                </a>
            </li>
            <!--<li class="sub-menu">
                <a href="javascript:;" class="">
                    <i class="icon-tasks"></i>
                    <span>Administration</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub">                    
                    <li><a class="" href="<?php //echo site_url('con_set_user/create'); ?>">Create User</a></li>
                    <li><a class="" href="<?php //echo site_url('con_set_user/view'); ?>">View User</a></li> 
                    <!--<li><a class="" href="">Reset Password</a></li>
                    <li><a class="" href="">Roll Change</a></li>  
                </ul>
            </li>-->
            <li class="sub-menu">
                <a href="javascript:;" class="">
                    <i class="icon-group"></i>
                    <span>Employee Detail</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub"> 
                    <li><a class="" href="<?php echo site_url('con_set_worker_profile/create'); ?>">Create Staff</a></li>
                    <li><a class="" href="<?php echo site_url('con_set_employee_info_detail/example'); ?>">Employee Detail</a></li> 
<!--                    <li><a class="" href="<?php //echo site_url('con_pro_employee_access_log/example'); ?>">Log Detail</a></li>                    -->
                </ul>
            </li>
<!--            <li class="sub-menu">
                <a href="javascript:;" class="">
                    <i class="icon-tasks"></i>
                    <span>Recruitment</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub">
                    <li><a class="" href="#">Create User</a></li>
                    <li><a class="" href="form_wizard.html">View User</a></li> 
                    <li><a class="" href="form_component.html">Reset Password</a></li>
                    <li><a class="" href="form_wizard.html">Roll Change</a></li> 
                </ul>
            </li>-->
            <li class="sub-menu">
                <a href="javascript:;" class="">
                    <i class="icon-cogs"></i>
                    <span>Operations</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub">
                    <!--<li><a class="" href="<?php //echo site_url('con_set_additonal_allowance_structure_worker/view'); ?>">Worker Allowance</a></li>-->
                    <!--<li><a class="" href="<?php //echo site_url('con_set_additonal_allowance_structure_staff/view'); ?>">Staff Allowance</a></li>-->
<!--                    <li><a class="" href="<?php //echo site_url('con_set_work_hour_breakdown/view'); ?>">Factory Policy</a></li>
                    <li><a class="" href="<?php //echo site_url('con_set_wages_breakdown/view'); ?>">Wages</a></li>-->
                    <!--<li><a class="" href="<?php //echo site_url('con_set_holiday/view'); ?>">Holidays</a></li>-->
                    <li><a class="" href="<?php echo site_url('con_pro_daily_leave_report/create'); ?>">Leave Approval</a></li>
                    <li><a class="" href="<?php echo site_url('con_pro_attn_mismatch_report/'); ?>">Mismatch Report</a></li>
                    <li><a class="" href="<?php echo site_url('con_pro_daily_absent_report/'); ?>">Daily Absent</a></li>
                    <li><a class="" href="<?php echo site_url('con_pro_employee_monthly_report/search'); ?>">Present & Mismatch</a></li>
                    <!--<li><a class="" href="<?php //echo site_url('con_set_leave_catagory/view'); ?>">Leave Category</a></li>-->
                    <!--<li><a class="" href="<?php //echo site_url('Con_set_additional_reward_worker/view'); ?>">Worker Reward</a></li>-->
                    <!--<li><a class="" href="<?php //echo site_url('con_set_additional_reward_staff/view'); ?>">Staff Reward</a></li>-->
                    <!--<li><a class="" href="<?php  //echo site_url('con_access_log/view'); ?>">Access Log</a></li>-->
                    <!--<li><a class="" href="<?php //echo site_url('con_set_grade_mapping'); ?>">Grade Mapping</a></li>-->
                </ul>
            </li>
            <li class="sub-menu">
                <a href="javascript:;" class="">
                    <i class="icon-book"></i>
                    <span>Report</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub">
                    <!--<li><a class="" href="<?php //echo site_url('con_proc_daily_report_generate/search'); ?>"></a></li>-->
                    <!--<li><a class="" href="<?php //echo site_url('con_proc_monthly_report_generate/view'); ?>">Monthly(D)</a></li>-->
                    <li><a class="" href="<?php echo site_url('con_proc_monthly_report_generate/view_monthly_report'); ?>">Wages Detail(M)</a></li>
                    <li><a class="" href="<?php echo site_url('con_pro_attn_mismatch_report/'); ?>">Mismatch Report</a></li>
                    <li><a class="" href="<?php echo site_url('con_pro_first_half_attendance_log/'); ?>">First Half Attendance</a></li>
                    <li><a class="" href="<?php echo site_url('con_pro_daily_absent_report/'); ?>">Daily Absent</a></li>
                    <li><a class="" href="<?php echo site_url('con_pro_daily_leave_report/'); ?>">Daily Leave Report</a></li>
                   <!-- <li><a class="" href="charts.html">In Time(D)</a></li> -->
                </ul>
            </li>
        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>